package com.museum.ticketbooking.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class VerificationRequest {

    @NotNull(message = "Ticket ID is required")
    private Long ticketId;

    @NotBlank(message = "Staff PIN is required")
    @Pattern(regexp = "^[0-9]{4}$", message = "Staff PIN must be 4 digits")
    private String staffPin;

    @NotNull(message = "Museum ID is required")
    private Long museumId;

    private String type; // optional: ENTRY / SHOW
}
