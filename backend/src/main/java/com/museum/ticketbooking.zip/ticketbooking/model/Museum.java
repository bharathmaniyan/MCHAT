package com.museum.ticketbooking.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "museums")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Museum {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "museum_name", nullable = false)
    private String museumName;
    
    @Column(unique = true, nullable = false)
    private String email;
    
    @Column(nullable = false)
    private String password;
    
    private String location;
    
    @Column(name = "adult_price")
    private Double adultPrice;
    
    @Column(name = "child_price")
    private Double childPrice;
    
    @Column(name = "seat_limit")
    private Integer seatLimit;
    
    @Column(name = "staff_pin", length = 4, nullable = false)
    private String staffPin;
    
    @Column(name = "verification_code")
    private String verificationCode;
    
    @Column(name = "booking_status")
    private Boolean bookingStatus = true;
    
    @Column(name = "qr_code_url", length = 1000)
    private String qrCodeUrl;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        if (verificationCode == null) {
            verificationCode = generateVerificationCode();
        }
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    private String generateVerificationCode() {
        return "MUS" + String.format("%04d", (int)(Math.random() * 10000));
    }
}
