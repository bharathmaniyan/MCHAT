package com.museum.ticketbooking.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class TicketBookingRequest {
    @NotNull(message = "Museum ID is required")
    private Long museumId;
    
    @Email(message = "Invalid email format")
    @NotBlank(message = "User email is required")
    private String userEmail;

    @NotBlank(message = "OTP is required for booking")
    private String otp;
    
    @NotBlank(message = "Phone number is required")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone must be 10 digits")
    private String phone;
    
    @Min(value = 0, message = "Adults count cannot be negative")
    private Integer adults;
    
    @Min(value = 0, message = "Children count cannot be negative")
    private Integer children;
    
    @AssertTrue(message = "At least one adult or child must be selected")
    private boolean isValidBooking() {
        return (adults != null && adults > 0) || (children != null && children > 0);
    }
}
