package com.museum.ticketbooking.service;

import com.museum.ticketbooking.dto.TicketBookingRequest;
import com.museum.ticketbooking.dto.VerificationRequest;
import com.museum.ticketbooking.model.Museum;
import com.museum.ticketbooking.model.Ticket;
import com.museum.ticketbooking.repository.MuseumRepository;
import com.museum.ticketbooking.repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final MuseumRepository museumRepository;
    
    public TicketService(TicketRepository ticketRepository, MuseumRepository museumRepository) {
        this.ticketRepository = ticketRepository;
        this.museumRepository = museumRepository;
    }

    @Transactional
    public Map<String, Object> createTicket(TicketBookingRequest request) {
        Museum museum = museumRepository.findById(request.getMuseumId())
                .orElseThrow(() -> new RuntimeException("Museum not found"));

        if (!Boolean.TRUE.equals(museum.getBookingStatus())) {
            throw new RuntimeException("Bookings are currently closed for this museum");
        }

        int adults = request.getAdults() == null ? 0 : request.getAdults();
        int children = request.getChildren() == null ? 0 : request.getChildren();

        double adultPrice = museum.getAdultPrice() == null ? 0 : museum.getAdultPrice();
        double childPrice = museum.getChildPrice() == null ? 0 : museum.getChildPrice();

        double total = (adults * adultPrice) + (children * childPrice);

        Ticket ticket = new Ticket();
        ticket.setMuseum(museum);
        ticket.setUserEmail(request.getUserEmail().trim().toLowerCase());
        ticket.setPhone(request.getPhone().trim());
        ticket.setAdults(adults);
        ticket.setChildren(children);
        ticket.setTotalPrice(total);
        ticket.setStatus("PENDING");

        Ticket savedTicket = ticketRepository.save(ticket);

        Map<String, Object> result = new HashMap<>();
        result.put("ticketId", savedTicket.getId());
        result.put("ticketNumber", savedTicket.getTicketNumber());
        result.put("secretCode", savedTicket.getSecretCode());
        result.put("totalPrice", savedTicket.getTotalPrice());
        result.put("museumName", museum.getMuseumName());
        result.put("status", savedTicket.getStatus());

        return result;
    }

    @Transactional
    public void savePaymentOrder(Long ticketId, String orderId) {
        Ticket ticket = getTicketById(ticketId);

        if (!"PENDING".equalsIgnoreCase(ticket.getStatus())) {
            throw new RuntimeException("Only PENDING ticket can receive payment order");
        }

        ticket.setOrderId(orderId);
        ticketRepository.save(ticket);
    }

    @Transactional
    public void activateTicketPayment(Long ticketId, String paymentId, String orderId) {
        Ticket ticket = getTicketById(ticketId);

        if ("ACTIVE".equalsIgnoreCase(ticket.getStatus())) {
            return;
        }

        if ("USED".equalsIgnoreCase(ticket.getStatus())) {
            throw new RuntimeException("Used ticket cannot be activated again");
        }

        if ("CANCELLED".equalsIgnoreCase(ticket.getStatus())) {
            throw new RuntimeException("Cancelled ticket cannot be activated");
        }

        ticket.setPaymentId(paymentId);
        ticket.setOrderId(orderId);
        ticket.setStatus("ACTIVE");
        ticketRepository.save(ticket);
    }

    public Ticket getTicketByOrderId(String orderId) {
        return ticketRepository.findByOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Ticket not found for order ID"));
    }

    @Transactional
    public boolean verifyTicket(VerificationRequest request) {
        Ticket ticket = ticketRepository.findById(request.getTicketId())
                .orElseThrow(() -> new RuntimeException("Ticket not found"));

        if (ticket.getMuseum() == null || !ticket.getMuseum().getId().equals(request.getMuseumId())) {
            throw new RuntimeException("Ticket does not belong to this museum");
        }

        if (!"ACTIVE".equalsIgnoreCase(ticket.getStatus())) {
            throw new RuntimeException("Ticket is not active. Current status: " + ticket.getStatus());
        }

        // SECURITY FIX: Check museum's staffPin instead of ticket's secretCode
        if (ticket.getMuseum().getStaffPin() == null || !ticket.getMuseum().getStaffPin().equals(request.getStaffPin().trim())) {
            throw new RuntimeException("Invalid 4-digit staff PIN");
        }

        ticket.setStatus("USED");
        ticket.setUsedAt(LocalDateTime.now());
        ticketRepository.save(ticket);

        return true;
    }

    public List<Ticket> getUserTickets(String email) {
        return ticketRepository.findByUserEmailOrderByCreatedAtDesc(email.trim().toLowerCase());
    }

    public List<Ticket> getMuseumTickets(Long museumId) {
        return ticketRepository.findByMuseum_IdOrderByCreatedAtDesc(museumId);
    }

    public List<Ticket> getTicketsByPhone(Long museumId, String phone) {
        return ticketRepository.findByMuseum_IdAndPhoneOrderByCreatedAtDesc(museumId, phone.trim());
    }

    public Ticket getTicketById(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
    }

    public Ticket getTicketByNumber(String ticketNumber) {
        return ticketRepository.findByTicketNumber(ticketNumber.trim())
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
    }

    @Transactional
    public Ticket cancelTicket(Long id) {
        Ticket ticket = getTicketById(id);

        if (!"ACTIVE".equalsIgnoreCase(ticket.getStatus()) && !"PENDING".equalsIgnoreCase(ticket.getStatus())) {
            throw new RuntimeException("Cannot cancel ticket with status: " + ticket.getStatus());
        }

        ticket.setStatus("CANCELLED");
        return ticketRepository.save(ticket);
    }

    public List<Ticket> getTodayTickets(Long museumId) {
        return ticketRepository.findTodayTicketsByMuseumId(museumId, LocalDate.now());
    }

    @Transactional
    public void updateTicketPayment(Long ticketId, String paymentId, String orderId) {
        Ticket ticket = getTicketById(ticketId);
        ticket.setPaymentId(paymentId);
        ticket.setOrderId(orderId);
        ticket.setStatus("ACTIVE");
        ticketRepository.save(ticket);
    }
}
