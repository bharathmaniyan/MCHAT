package com.museum.ticketbooking.service;

import com.museum.ticketbooking.dto.LoginRequest;
import com.museum.ticketbooking.dto.MuseumRegistrationDTO;
import com.museum.ticketbooking.model.Museum;
import com.museum.ticketbooking.repository.MuseumRepository;
import com.museum.ticketbooking.repository.TicketRepository;
import com.museum.ticketbooking.repository.ShowRepository;
import com.museum.ticketbooking.util.JwtUtil;
import com.museum.ticketbooking.util.QRCodeGenerator;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MuseumService {
    
    private final MuseumRepository museumRepository;
    private final TicketRepository ticketRepository;
    private final ShowRepository showRepository;
    private final PasswordEncoder passwordEncoder;
    private final QRCodeGenerator qrCodeGenerator;
    private final JwtUtil jwtUtil;
    
    public MuseumService(MuseumRepository museumRepository, TicketRepository ticketRepository,
                         ShowRepository showRepository, PasswordEncoder passwordEncoder,
                         QRCodeGenerator qrCodeGenerator, JwtUtil jwtUtil) {
        this.museumRepository = museumRepository;
        this.ticketRepository = ticketRepository;
        this.showRepository = showRepository;
        this.passwordEncoder = passwordEncoder;
        this.qrCodeGenerator = qrCodeGenerator;
        this.jwtUtil = jwtUtil;
    }
    
    @Transactional
    public Museum registerMuseum(MuseumRegistrationDTO request) {
        // Check if email already exists
        if (museumRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }
        
        // Create new museum
        Museum museum = new Museum();
        museum.setMuseumName(request.getMuseumName());
        museum.setLocation(request.getLocation());
        museum.setEmail(request.getEmail());
        museum.setPassword(passwordEncoder.encode(request.getPassword()));
        museum.setSeatLimit(request.getSeatCapacity());
        museum.setAdultPrice(request.getAdultTicketPrice());
        museum.setChildPrice(request.getChildTicketPrice());
        museum.setBookingStatus(true);
        // Generate random 4-digit staff PIN
        museum.setStaffPin(generateRandomStaffPin());
        
        // Save to get ID
        Museum savedMuseum = museumRepository.save(museum);
        
        // Generate QR Code
        String qrCodeContent = "http://localhost:5173/museum/" + savedMuseum.getId();
        String qrCodePath = qrCodeGenerator.generateQRCode(qrCodeContent, savedMuseum.getId());
        savedMuseum.setQrCodeUrl(qrCodePath);
        
        return museumRepository.save(savedMuseum);
    }
    
    public Map<String, Object> authenticate(LoginRequest request) {
        Museum museum = museumRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new RuntimeException("Invalid email or password"));
        
        if (!passwordEncoder.matches(request.getPassword(), museum.getPassword())) {
            throw new RuntimeException("Invalid email or password");
        }
        
        String token = jwtUtil.generateToken(museum.getId().toString(), museum.getEmail(), "MUSEUM");
        
        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("museumId", museum.getId());
        response.put("museumName", museum.getMuseumName());
        response.put("email", museum.getEmail());
        
        return response;
    }
    
    public Museum getMuseumById(Long id) {
        return museumRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Museum not found"));
    }
    
    public List<Museum> getAllMuseums() {
        return museumRepository.findAllActiveMuseums();
    }
    
    @Transactional
    public Museum updateMuseum(Long id, Museum updatedMuseum) {
        Museum museum = getMuseumById(id);
        
        if (updatedMuseum.getMuseumName() != null) {
            museum.setMuseumName(updatedMuseum.getMuseumName());
        }
        if (updatedMuseum.getLocation() != null) {
            museum.setLocation(updatedMuseum.getLocation());
        }
        if (updatedMuseum.getAdultPrice() != null) {
            museum.setAdultPrice(updatedMuseum.getAdultPrice());
        }
        if (updatedMuseum.getChildPrice() != null) {
            museum.setChildPrice(updatedMuseum.getChildPrice());
        }
        if (updatedMuseum.getSeatLimit() != null) {
            museum.setSeatLimit(updatedMuseum.getSeatLimit());
        }
        if (updatedMuseum.getBookingStatus() != null) {
            museum.setBookingStatus(updatedMuseum.getBookingStatus());
        }
        if (updatedMuseum.getVerificationCode() != null) {
            museum.setVerificationCode(updatedMuseum.getVerificationCode());
        }
        
        return museumRepository.save(museum);
    }
    
    @Transactional
    public Museum updateBookingStatus(Long id, boolean status) {
        Museum museum = getMuseumById(id);
        museum.setBookingStatus(status);
        return museumRepository.save(museum);
    }
    
    @Transactional
    public String regenerateQRCode(Long id) {
        Museum museum = getMuseumById(id);
        String qrCodeContent = "http://localhost:5173/museum/" + museum.getId();
        String qrCodePath = qrCodeGenerator.generateQRCode(qrCodeContent, museum.getId());
        museum.setQrCodeUrl(qrCodePath);
        museumRepository.save(museum);
        return qrCodePath;
    }
    
    public Map<String, Object> getMuseumStatistics(Long id) {
        Museum museum = getMuseumById(id);
        
        Long todayTickets = ticketRepository.countTodayTickets(id);
        Double todayRevenue = ticketRepository.getTodayRevenue(id);
        List<String> activeTickets = ticketRepository.findByMuseumIdAndStatus(id, "ACTIVE").stream()
            .map(t -> t.getTicketNumber())
            .toList();
        Long totalShows = showRepository.countByMuseumId(id);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("museumId", id);
        stats.put("museumName", museum.getMuseumName());
        stats.put("todayTicketsCount", todayTickets);
        stats.put("todayRevenue", todayRevenue);
        stats.put("activeBookingsCount", activeTickets.size());
        stats.put("totalShowsCount", totalShows);
        stats.put("seatLimit", museum.getSeatLimit());
        stats.put("bookingStatus", museum.getBookingStatus());
        
        return stats;
    }
    
    /**
     * Generate a random 4-digit staff PIN (1000-9999)
     */
    private String generateRandomStaffPin() {
        int randomPin = 1000 + (int)(Math.random() * 9000);
        return String.format("%04d", randomPin);
    }
}
