package com.museum.ticketbooking.controller;

import com.museum.ticketbooking.dto.ApiResponse;
import com.museum.ticketbooking.dto.SendOtpRequest;
import com.museum.ticketbooking.dto.TicketBookingRequest;
import com.museum.ticketbooking.dto.VerificationRequest;
import com.museum.ticketbooking.model.Ticket;
import com.museum.ticketbooking.service.OtpService;
import com.museum.ticketbooking.service.TicketService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tickets")
@CrossOrigin(origins = "http://localhost:5173")
public class TicketController {
    
    private final TicketService ticketService;
    private final OtpService otpService;
    
    public TicketController(TicketService ticketService, OtpService otpService) {
        this.ticketService = ticketService;
        this.otpService = otpService;
    }
    
    @PostMapping("/send-otp")
    public ResponseEntity<ApiResponse<String>> sendOtp(@Valid @RequestBody SendOtpRequest request) {
        try {
            otpService.sendOtp(request.getEmail());
            return ResponseEntity.ok(ApiResponse.success("OTP sent successfully", "Check your email"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/resend-otp")
    public ResponseEntity<ApiResponse<String>> resendOtp(@Valid @RequestBody SendOtpRequest request) {
        try {
            otpService.sendOtp(request.getEmail());
            return ResponseEntity.ok(ApiResponse.success("OTP resent successfully", "Check your email"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/verify")
    public ResponseEntity<ApiResponse<Map<String, Object>>> verifyTicket(
            @Valid @RequestBody VerificationRequest request) {
        try {
            boolean verified = ticketService.verifyTicket(request);
            Map<String, Object> data = new HashMap<>();
            data.put("verified", verified);
            data.put("ticketId", request.getTicketId());
            
            return ResponseEntity.ok(ApiResponse.success(
                verified ? "Ticket verified successfully" : "Ticket verification failed", 
                data
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/user/{email}")
    public ResponseEntity<ApiResponse<List<Ticket>>> getUserTickets(@PathVariable String email) {
        try {
            List<Ticket> tickets = ticketService.getUserTickets(email);
            return ResponseEntity.ok(ApiResponse.success("Tickets retrieved successfully", tickets));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/museum/{museumId}")
    public ResponseEntity<ApiResponse<List<Ticket>>> getMuseumTickets(@PathVariable Long museumId) {
        try {
            List<Ticket> tickets = ticketService.getMuseumTickets(museumId);
            return ResponseEntity.ok(ApiResponse.success("Tickets retrieved successfully", tickets));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/museum/{museumId}/phone/{phone}")
    public ResponseEntity<ApiResponse<List<Ticket>>> getTicketsByPhone(@PathVariable Long museumId, @PathVariable String phone) {
        try {
            List<Ticket> tickets = ticketService.getTicketsByPhone(museumId, phone);
            return ResponseEntity.ok(ApiResponse.success("Tickets retrieved successfully", tickets));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/{ticketId}")
    public ResponseEntity<ApiResponse<Ticket>> getTicketById(@PathVariable Long ticketId) {
        try {
            Ticket ticket = ticketService.getTicketById(ticketId);
            return ResponseEntity.ok(ApiResponse.success("Ticket found", ticket));
        } catch (RuntimeException e) {
            return ResponseEntity.status(404)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/number/{ticketNumber}")
    public ResponseEntity<ApiResponse<Ticket>> getTicketByNumber(@PathVariable String ticketNumber) {
        try {
            Ticket ticket = ticketService.getTicketByNumber(ticketNumber);
            return ResponseEntity.ok(ApiResponse.success("Ticket found", ticket));
        } catch (RuntimeException e) {
            return ResponseEntity.status(404)
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/{ticketId}/cancel")
    public ResponseEntity<ApiResponse<Ticket>> cancelTicket(@PathVariable Long ticketId) {
        try {
            Ticket ticket = ticketService.cancelTicket(ticketId);
            return ResponseEntity.ok(ApiResponse.success("Ticket cancelled successfully", ticket));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/museum/{museumId}/today")
    public ResponseEntity<ApiResponse<List<Ticket>>> getTodayTickets(@PathVariable Long museumId) {
        try {
            List<Ticket> tickets = ticketService.getTodayTickets(museumId);
            return ResponseEntity.ok(ApiResponse.success("Today's tickets retrieved", tickets));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}
