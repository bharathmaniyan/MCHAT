package com.museum.ticketbooking.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "ticket_number", unique = true)
    private String ticketNumber;
    
    @ManyToOne
    @JoinColumn(name = "museum_id")
    private Museum museum;
    
    @Column(name = "user_email")
    private String userEmail;

    private String phone;
    
    private Integer adults;
    
    private Integer children;
    
    @Column(name = "total_price")
    private Double totalPrice;
    
    @Column(name = "payment_id")
    private String paymentId;
    
    @Column(name = "order_id")
    private String orderId;
    
    @Column(name = "secret_code")
    private String secretCode;
    
    private String status;
    
    @Column(name = "email_sent")
    private Boolean emailSent = false;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "used_at")
    private LocalDateTime usedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (status == null || status.isBlank()) {
            status = "PENDING";
        }
        if (ticketNumber == null || ticketNumber.isBlank()) {
            ticketNumber = "TKT" + System.currentTimeMillis();
        }
        if (secretCode == null || secretCode.isBlank()) {
            secretCode = String.format("%04d", (int) (Math.random() * 9000) + 1000);
        }
    }
}
